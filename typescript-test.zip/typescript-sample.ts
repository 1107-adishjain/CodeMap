// TypeScript test file with explicit return types and rich relationships

import { Express } from 'express';
import * as lodash from 'lodash';

// Interface definitions
interface User {
  id: number;
  name: string;
  email: string;
}

interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
}

// Class with methods and properties
export class UserService {
  private users: User[] = [];
  public readonly serviceName: string = 'UserService';

  constructor(initialUsers: User[]) {
    this.users = initialUsers;
  }

  // Method with explicit return type and parameters
  public addUser(user: User): boolean {
    this.users.push(user);
    return this.validateUser(user);
  }

  // Method with array return type
  public getUsers(): User[] {
    return this.users.filter(user => this.isActiveUser(user));
  }

  // Method with union return type
  public findUserById(id: number): User | null {
    const user = this.users.find(u => u.id === id);
    return user || null;
  }

  // Private method with boolean return
  private validateUser(user: User): boolean {
    return user.name.length > 0 && user.email.includes('@');
  }

  // Private method called by getUsers
  private isActiveUser(user: User): boolean {
    return this.validateUser(user) && user.id > 0;
  }

  // Method that calls external function
  public getUserCount(): number {
    return calculateTotalCount(this.users);
  }
}

// Standalone function with explicit return type
export function calculateTotalCount(items: any[]): number {
  return lodash.size(items);
}

// Function with promise return type
export async function fetchUserData(userId: number): Promise<User | null> {
  const service = new UserService([]);
  const user = service.findUserById(userId);
  return await processUserAsync(user);
}

// Function with void return type
export function logUserActivity(user: User): void {
  console.log(`User ${user.name} performed an action`);
  updateUserStats(user);
}

// Function with complex return type
function processUserAsync(user: User | null): Promise<User | null> {
  return new Promise((resolve) => {
    if (user) {
      logUserActivity(user);
    }
    resolve(user);
  });
}

// Function that calls other functions
function updateUserStats(user: User): void {
  const count = calculateTotalCount([user]);
  console.log(`Updated stats for user with count: ${count}`);
}

// Export default class
export default class ProductService {
  private products: Product[] = [];

  public addProduct(product: Product): Product {
    this.products.push(product);
    return this.formatProduct(product);
  }

  public getProductsByCategory(category: string): Product[] {
    return this.products.filter(p => p.category === category);
  }

  private formatProduct(product: Product): Product {
    return {
      ...product,
      name: product.name.toUpperCase()
    };
  }
}