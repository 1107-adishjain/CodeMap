// Additional TypeScript file to test cross-file relationships

export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message: string;
}

export type Status = 'active' | 'inactive' | 'pending';

// Class that will import and use UserService
export class ApiController {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  // Method with generic return type
  public async handleRequest<T>(endpoint: string): Promise<ApiResponse<T>> {
    const response = await this.makeHttpCall(endpoint);
    return this.formatResponse<T>(response);
  }

  // Private method with string return
  private async makeHttpCall(endpoint: string): Promise<any> {
    console.log(`Making request to: ${this.baseUrl}${endpoint}`);
    return { data: null, status: 200 };
  }

  // Method with generic parameter and return
  private formatResponse<T>(response: any): ApiResponse<T> {
    return {
      data: response.data,
      success: response.status === 200,
      message: this.getStatusMessage(response.status)
    };
  }

  // Method with number parameter and string return
  private getStatusMessage(status: number): string {
    switch (status) {
      case 200: return 'Success';
      case 404: return 'Not Found'; 
      case 500: return 'Server Error';
      default: return 'Unknown Status';
    }
  }
}

// Utility functions with various return types
export function isValidEmail(email: string): boolean {
  return email.includes('@') && email.includes('.');
}

export function generateId(): number {
  return Math.floor(Math.random() * 1000000);
}

export function getCurrentTimestamp(): Date {
  return new Date();
}

// Function that returns array
export function createDefaultUsers(): Array<{id: number, name: string}> {
  return [
    { id: generateId(), name: 'John Doe' },
    { id: generateId(), name: 'Jane Smith' }
  ];
}