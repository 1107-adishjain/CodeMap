def hello_world():
    """A simple test function"""
    print("Hello, World!")
    return "success"

class TestClass:
    def __init__(self, name):
        self.name = name
    
    def greet(self):
        return f"Hello, {self.name}!"

if __name__ == "__main__":
    hello_world()
    test = TestClass("CodeMap")
    print(test.greet())